console.log(navigator.userAgent);
